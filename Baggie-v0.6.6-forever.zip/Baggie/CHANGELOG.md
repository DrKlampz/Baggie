# Baggie

## [v0.6.6](https://github.com/DrKlampz/Baggie/tree/v0.6.6) (2026-11-13)
[Full Changelog](https://github.com/DrKlampz/Baggie/compare/v0.6.5...v0.6.6) [Previous Releases](https://github.com/DrKlampz/Baggie/releases)

- Baggie v0.6.6: keep saved spots free of new loot  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
