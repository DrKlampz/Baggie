# Baggie

## [v0.6.4](https://github.com/DrKlampz/Baggie/tree/v0.6.4) (2026-11-13)
[Full Changelog](https://github.com/DrKlampz/Baggie/compare/v0.6.3...v0.6.4) [Previous Releases](https://github.com/DrKlampz/Baggie/releases)

- Baggie v0.6.4  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Baggie: money display options, font pack, slot options per style, GreedUI sync only on theme change  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Bank: hide the game's window right after a tab is bought  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Bank: keep the bank open after buying a tab (make the game's window invisible instead of hiding it)  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Bank: buy tabs through the game's own bank window (add-on calls are blocked)  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Bank: say which buy-tab path ran  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Bank: buy a bank tab through the game's confirm popup, report refusals  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
