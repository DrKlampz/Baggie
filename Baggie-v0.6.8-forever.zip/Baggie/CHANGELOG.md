# Baggie

## [v0.6.8](https://github.com/DrKlampz/Baggie/tree/v0.6.8) (2026-11-16)
[Full Changelog](https://github.com/DrKlampz/Baggie/compare/v0.6.7...v0.6.8) [Previous Releases](https://github.com/DrKlampz/Baggie/releases)

- v0.6.8: log who hides the tooltip while hovering  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- v0.6.8: put the tooltip back if it vanishes while hovering  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- v0.6.8: restore the tooltip in combat too  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- v0.6.8: keep the item tooltip when the bag redraws  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
