# Baggie

## [v0.6.5](https://github.com/DrKlampz/Baggie/tree/v0.6.5) (2026-11-13)
[Full Changelog](https://github.com/DrKlampz/Baggie/compare/v0.6.4...v0.6.5) [Previous Releases](https://github.com/DrKlampz/Baggie/releases)

- Baggie v0.6.5  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Baggie: keep the Buy tab button above the window background  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
